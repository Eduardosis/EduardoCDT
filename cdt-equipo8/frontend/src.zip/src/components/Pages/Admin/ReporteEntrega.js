import React, { useState, useEffect } from "react";
import axios from 'axios';
import NavBarAdmin from "../../NavBar/NavBarAdmin";
import Footer from '../../Footer/Footer';
import '../../Css/ReporteEntrega.css'; 
import { FaArrowLeft } from 'react-icons/fa';
import { useNavigate } from 'react-router-dom';

const ReporteEntregas = () => {
  const [entregas, setEntregas] = useState([]);
  const [ordenesEnvio, setOrdenesEnvio] = useState([]);
  const [formData, setFormData] = useState({
    estatus: '',
    descripcion: '',
    almacen: '',
    entrega: '',
    ordenenvio: ''
  });
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    const usuarioId = localStorage.getItem('id'); // Obtener el ID del usuario desde localStorage
    console.log('Usuario ID from localStorage:', usuarioId);

    // Obtener el almacén asociado al usuario
    axios.get('http://127.0.0.1:8000/api/agr-almacen/')
      .then(response => {
        console.log('Response data:', response.data);
        const almacenUsuario = response.data.find(almacen => almacen.usuario === parseInt(usuarioId));
        if (almacenUsuario) {
          const idAlmacen = almacenUsuario.idalmacen;
          console.log('Almacén ID:', idAlmacen);
          setFormData(prevData => ({
            ...prevData,
            almacen: idAlmacen
          }));
        } else {
          console.error('No se encontró un almacén para el usuario.');
        }
      })
      .catch(error => console.error('Error fetching almacenes:', error));

    // Cargar datos de entregas
    axios.get('http://127.0.0.1:8000/api/ee-entrega/')
      .then(response => setEntregas(response.data))
      .catch(error => console.error('Error fetching entregas:', error));

    // Cargar datos de ordenes de envio
    axios.get('http://127.0.0.1:8000/api/p-ordenenvio/')
      .then(response => setOrdenesEnvio(response.data))
      .catch(error => console.error('Error fetching ordenesEnvio:', error));
  }, []);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prevData => ({
      ...prevData,
      [name]: value
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log('Form Data before sending:', formData);
    axios.post('http://127.0.0.1:8000/api/agr-reporteentrega/', formData)
      .then(response => {
        console.log('Reporte de entrega enviado:', response.data);
        setMessage('Reporte de entrega enviado exitosamente.');
        setError('');
        setTimeout(() => {
          window.location.reload(); // Recargar la página después de 2 segundos
        }, 2000);
      })
      .catch(error => {
        console.error('Error enviando reporte de entrega:', error);
        setMessage('');
        setError('Error al enviar el reporte de entrega. Por favor, inténtalo de nuevo.');
      });
  };

  const goToAdminDashb = () => {
    navigate('/admin');
  };

  return (
    <div className="full">
      <NavBarAdmin />
      <FaArrowLeft className="back-arrow3" size={30} onClick={goToAdminDashb} />
      <div className="entregas-form">
        <h1 className="titles">Reporte de Entregas</h1>
        <form className="form" onSubmit={handleSubmit}>
          <div className="form-row">
            <div className="form-group">
              <label htmlFor="estatus">Estatus</label>
              <select
                id="estatus"
                name="estatus"
                value={formData.estatus}
                onChange={handleChange}
                required
              >
                <option value="">Selecciona un estatus</option>
                <option value="Entregado">Entregado</option>
                <option value="Cancelado">Cancelado</option>
              </select>
            </div>
            <div className="form-group">
              <label htmlFor="descripcion" className="label">Descripción</label>
              <textarea
                id="descripcion"
                name="descripcion"
                rows="5"
                className="input textarea"
                value={formData.descripcion}
                onChange={handleChange}
                required
              />
            </div>
          </div>
          <div className="form-row">
            <div className="form-group">
              <label htmlFor="entrega" className="label">Entrega</label>
              <select
                id="entrega"
                name="entrega"
                className="input"
                value={formData.entrega}
                onChange={handleChange}
                required
              >
                <option value="">Selecciona una entrega</option>
                {entregas.map(entrega => (
                  <option key={entrega.identrega} value={entrega.identrega}>
                    {entrega.identrega}
                  </option>
                ))}
              </select>
            </div>
            <div className="form-group">
              <label htmlFor="ordenenvio" className="label">Orden de Envío</label>
              <select
                id="ordenenvio"
                name="ordenenvio"
                className="input"
                value={formData.ordenenvio}
                onChange={handleChange}
                required
              >
                <option value="">Selecciona una orden de envío</option>
                {ordenesEnvio.map(orden => (
                  <option key={orden.idordenenvio} value={orden.idordenenvio}>
                    {orden.idordenenvio}
                  </option>
                ))}
              </select>
            </div>
          </div>
          <button type="submit">Enviar</button>
        </form>
        {message && <p className="success-message">{message}</p>}
        {error && <p className="error-message">{error}</p>}
      </div>
      <Footer />
    </div>
  );
};

export default ReporteEntregas;
